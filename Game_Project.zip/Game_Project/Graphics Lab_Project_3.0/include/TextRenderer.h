#pragma once
#include <vector>

// ── PixelQuad ─────────────────────────────────────────────────────────────────
struct PixelQuad { float x, y, w, h; }; // x,y = top-left corner in NDC

// ── Font declarations (defined in TextRenderer.cpp) ───────────────────────────

// Game-over overlay fonts
extern const unsigned char FONT_GAMEOVER[9][5];
extern const unsigned char FONT_YOUWIN  [7][5];
extern const unsigned char FONT_YOULOSE [8][5];

// Title screen
extern const unsigned char FONT_TITLE_ROW1[8][5];   // "DODGE ME"
extern const unsigned char FONT_TITLE_ROW2[10][5];  // "IF YOU CAN"
extern const unsigned char FONT_HINT       [19][5]; // "PRESS SPACE TO PLAY"
extern const unsigned char FONT_EXIT_HINT  [12][5]; // "E / N : EXIT"

// In-game / game-over prompts
extern const unsigned char FONT_RECORD_BANNER   [20][5]; // "YOU BEAT THE RECORD!"
extern const unsigned char FONT_PLAY_AGAIN_PROMPT[13][5]; // "R : PLAY AGAIN"
extern const unsigned char FONT_EXIT_PROMPT      [10][5]; // "E / N:EXIT"

// ── Functions (defined in TextRenderer.cpp) ───────────────────────────────────

// Build pixel-quad list from a glyph array
void buildText(const unsigned char glyphs[][5], int numChars,
               float startX, float startY, float scale,
               std::vector<PixelQuad>& quads);

// Upload one quad to textVBO and draw it immediately
void drawPixelQuad(unsigned int textVBO,
                   int offsetLoc, int colorLoc,
                   const PixelQuad& q,
                   float r, float g, float b);

// Build + draw a complete string in one call (no quad cache needed)
void drawTextDirect(unsigned int textVBO,
                    int offsetLoc, int colorLoc,
                    const unsigned char glyphs[][5], int numChars,
                    float startX, float startY, float scale,
                    float r, float g, float b);

// Pre-build the three game-over overlay quad lists
void prepareGameOverText(std::vector<PixelQuad>& gameOverQuads,
                         std::vector<PixelQuad>& youWinQuads,
                         std::vector<PixelQuad>& youLoseQuads,
                         float PIX);
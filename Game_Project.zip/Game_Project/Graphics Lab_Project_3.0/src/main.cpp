#include "glad.h"
#include "glfw3.h"
#include <cmath>
#include <ctime>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

#include "TextRenderer.h"

// ── Window ────────────────────────────────────────────────────────────────────
const unsigned int SCR_WIDTH  = 800;
const unsigned int SCR_HEIGHT = 600;
void framebuffer_size_callback(GLFWwindow* window, int width, int height);

// ── Game screens ──────────────────────────────────────────────────────────────
enum class Screen { TITLE, PLAYING, GAME_OVER };
Screen currentScreen = Screen::TITLE;

// ── Player ────────────────────────────────────────────────────────────────────
float playerX            =  0.0f;
float playerY            = -0.6f;
const float PLAYER_Y_HOME    = -0.6f;
const float playerHalfWidth  =  0.05f;
const float playerHalfHeight =  0.05f;
float playerSpeed        =  1.2f;

// ── Dash ability (charge-based) ───────────────────────────────────────────────
enum class DashState { IDLE, LUNGING, RETURNING };
DashState   dashState        = DashState::IDLE;
// Longer air time: slower lunge + slower return + bigger distance
const float DASH_DIST        =  0.45f;  // higher arc
const float DASH_SPEED       =  2.8f;   // slow rise = long hang
const float RETURN_SPEED     =  1.5f;   // slow return = even longer hang
float       dashTargetY      =  0.0f;
bool        dashKeyHeld      = false;
const int   DASH_CHARGE_MAX  = 5;
int         dashCharge       = 0;
bool        dashReady        = false;

// ── Obstacles ─────────────────────────────────────────────────────────────────
struct Obstacle { float x, y, speed, spawnDelay; bool active; };
std::vector<Obstacle> obstacles;
const float obstacleHalfSize  = 0.07f;
const int   INITIAL_OBSTACLES = 5;
const int   MAX_OBSTACLES     = 20;
float nextObstacleSpawn       = 20.0f;
int   obstacleSpawnInterval   = 20;

// ── Speed ─────────────────────────────────────────────────────────────────────
float speedMultiplier   = 1.0f;
float nextSpeedIncrease = 20.0f;

// ── Score / record ────────────────────────────────────────────────────────────
const std::string SCORE_FILE = "scores.txt";
const int         MAX_SCORES = 5;
std::vector<int>  highScores;
bool  gameOver        = false;
bool  beatHighScore   = false;   // did this run beat the previous top?
bool  recordBeatenMid = false;   // flips true once player passes top score live
int   prevTopScore    = 0;       // top score when the round started
int   finalTime       = 0;

void loadScores()
{
    highScores.clear();
    std::ifstream f(SCORE_FILE);
    if (!f.is_open()) return;
    int s;
    while (f >> s && (int)highScores.size() < MAX_SCORES)
        highScores.push_back(s);
}
void saveScores()
{
    std::ofstream f(SCORE_FILE);
    for (int s : highScores) f << s << "\n";
}
bool submitScore(int seconds)
{
    bool beaten = highScores.empty() || seconds > highScores[0];
    highScores.push_back(seconds);
    std::sort(highScores.begin(), highScores.end(), std::greater<int>());
    if ((int)highScores.size() > MAX_SCORES) highScores.resize(MAX_SCORES);
    saveScores();
    return beaten;
}

// ── Shaders ───────────────────────────────────────────────────────────────────
const char *vertexShaderSource = R"(
#version 330 core
layout (location = 0) in vec2 aPos;
uniform vec2 offset;
void main() { gl_Position = vec4(aPos + offset, 0.0, 1.0); }
)";
const char *fragmentShaderSource = R"(
#version 330 core
out vec4 FragColor;
uniform vec4 ourColor;
void main() { FragColor = ourColor; }
)";

// ── Obstacle helpers ──────────────────────────────────────────────────────────
bool tooCloseToOthers(float x, float y)
{
    const float MIN_GAP = obstacleHalfSize * 2.6f;
    for (auto& o : obstacles)
        if (o.active && fabs(o.x-x) < MIN_GAP && fabs(o.y-y) < MIN_GAP)
            return true;
    return false;
}
Obstacle createObstacle(float delay = 0.0f)
{
    Obstacle ob;
    for (int i = 0; i < 12; ++i) {
        ob.x = ((rand()%180)-90)/100.0f;
        ob.y = 1.1f + (rand()%180)/100.0f;
        if (!tooCloseToOthers(ob.x, ob.y)) break;
    }
    ob.speed = 0.30f + (rand()%160)/400.0f;
    ob.spawnDelay = delay;
    ob.active = (delay <= 0.0f);
    return ob;
}
void resetObstacle(Obstacle& ob)
{
    for (int i = 0; i < 12; ++i) {
        ob.x = ((rand()%180)-90)/100.0f;
        ob.y = 1.1f + (rand()%180)/100.0f;
        if (!tooCloseToOthers(ob.x, ob.y)) break;
    }
    ob.speed  = 0.30f + (rand()%160)/400.0f;
    ob.active = true;
}
bool checkCollision(float px, float py, float ox, float oy)
{
    return fabs(px-ox) < (playerHalfWidth  + obstacleHalfSize)
        && fabs(py-oy) < (playerHalfHeight + obstacleHalfSize);
}

// ── Reset everything for Play Again ──────────────────────────────────────────
void resetGame(double& startTime, double& lastTime)
{
    playerX       = 0.0f;
    playerY       = PLAYER_Y_HOME;
    playerSpeed   = 1.2f;
    dashState     = DashState::IDLE;
    dashCharge    = 0;
    dashReady     = false;
    dashKeyHeld   = false;
    speedMultiplier   = 1.0f;
    nextSpeedIncrease = 20.0f;
    nextObstacleSpawn = 20.0f;
    gameOver      = false;
    beatHighScore = false;
    recordBeatenMid = false;
    finalTime     = 0;
    prevTopScore  = highScores.empty() ? 0 : highScores[0];

    obstacles.clear();
    obstacles.reserve(MAX_OBSTACLES);
    for (int i = 0; i < INITIAL_OBSTACLES; ++i)
        obstacles.push_back(createObstacle(i * (0.6f + (rand()%80)/100.0f)));

    startTime = glfwGetTime();
    lastTime  = startTime;
    currentScreen = Screen::PLAYING;
}

// ── main ──────────────────────────────────────────────────────────────────────
int main()
{
    srand((unsigned int)time(NULL));
    loadScores();

    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // ── #6 Game title in window bar ───────────────────────────────────────────
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT,
                                          "Dodge Me If You Can", NULL, NULL);
    if (!window) { glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) return -1;

    // Shaders
    auto mkShader = [](GLenum type, const char* src) {
        unsigned int s = glCreateShader(type);
        glShaderSource(s, 1, &src, NULL);
        glCompileShader(s);
        return s;
    };
    unsigned int vs = mkShader(GL_VERTEX_SHADER,   vertexShaderSource);
    unsigned int fs = mkShader(GL_FRAGMENT_SHADER, fragmentShaderSource);
    unsigned int prog = glCreateProgram();
    glAttachShader(prog, vs); glAttachShader(prog, fs);
    glLinkProgram(prog);
    glDeleteShader(vs); glDeleteShader(fs);

    int offsetLoc = glGetUniformLocation(prog, "offset");
    int colorLoc  = glGetUniformLocation(prog, "ourColor");

    // Player VAO
    float playerVerts[] = {
        -playerHalfWidth,-playerHalfHeight,
         playerHalfWidth,-playerHalfHeight,
         0.0f,            playerHalfHeight
    };
    unsigned int triVAO, triVBO;
    glGenVertexArrays(1,&triVAO); glGenBuffers(1,&triVBO);
    glBindVertexArray(triVAO);
    glBindBuffer(GL_ARRAY_BUFFER, triVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(playerVerts), playerVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,2*sizeof(float),(void*)0);
    glEnableVertexAttribArray(0);

    // Obstacle VAO
    float sqVerts[] = {
        -obstacleHalfSize,-obstacleHalfSize,
         obstacleHalfSize,-obstacleHalfSize,
         obstacleHalfSize, obstacleHalfSize,
         obstacleHalfSize, obstacleHalfSize,
        -obstacleHalfSize, obstacleHalfSize,
        -obstacleHalfSize,-obstacleHalfSize
    };
    unsigned int sqVAO, sqVBO;
    glGenVertexArrays(1,&sqVAO); glGenBuffers(1,&sqVBO);
    glBindVertexArray(sqVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sqVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(sqVerts), sqVerts, GL_STATIC_DRAW);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,2*sizeof(float),(void*)0);
    glEnableVertexAttribArray(0);

    // Dynamic text VAO
    float dummy[12] = {};
    unsigned int textVAO, textVBO;
    glGenVertexArrays(1,&textVAO); glGenBuffers(1,&textVBO);
    glBindVertexArray(textVAO);
    glBindBuffer(GL_ARRAY_BUFFER, textVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(dummy), dummy, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,2*sizeof(float),(void*)0);
    glEnableVertexAttribArray(0);

    // Build all text quads from TextRenderer
    const float PIX = 0.026f;
    std::vector<PixelQuad> gameOverQuads, youWinQuads, youLoseQuads;
    prepareGameOverText(gameOverQuads, youWinQuads, youLoseQuads, PIX);

    // Spawn initial obstacles
    obstacles.reserve(MAX_OBSTACLES);
    for (int i = 0; i < INITIAL_OBSTACLES; ++i)
        obstacles.push_back(createObstacle(i * (0.6f + (rand()%80)/100.0f)));

    prevTopScore = highScores.empty() ? 0 : highScores[0];

    double startTime = glfwGetTime();
    double lastTime  = startTime;

    // Edge-detect booleans for one-shot key presses on game-over screen
    bool rKeyWasUp     = true;
    bool eKeyWasUp     = true;
    bool nKeyWasUp     = true;
    bool spaceKeyWasUp = true;

    // ── Game loop ─────────────────────────────────────────────────────────────
    while (!glfwWindowShouldClose(window))
    {
        double now     = glfwGetTime();
        float  dt      = (float)(now - lastTime);
        lastTime = now;
        float  elapsed = (float)(now - startTime);

        glfwPollEvents();

        // ── #5 Exit on E or N at any time ────────────────────────────────────
        bool eDown = (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS);
        bool nDown = (glfwGetKey(window, GLFW_KEY_N) == GLFW_PRESS);
        if ((eDown && eKeyWasUp) || (nDown && nKeyWasUp))
            glfwSetWindowShouldClose(window, true);
        eKeyWasUp = !eDown;
        nKeyWasUp = !nDown;

        // ── TITLE screen ─────────────────────────────────────────────────────
        if (currentScreen == Screen::TITLE)
        {
            bool spaceDown = (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS);
            if (spaceDown && spaceKeyWasUp)
                resetGame(startTime, lastTime);
            spaceKeyWasUp = !spaceDown;
        }

        // ── PLAYING screen ────────────────────────────────────────────────────
        else if (currentScreen == Screen::PLAYING && !gameOver)
        {
            playerSpeed = 1.2f + std::min(elapsed / 10.0f, 14.0f) * 0.1f;

            // Left / Right
            if (glfwGetKey(window, GLFW_KEY_LEFT)  == GLFW_PRESS) playerX -= playerSpeed * dt;
            if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) playerX += playerSpeed * dt;
            playerX = std::max(playerX, -1.0f + playerHalfWidth);
            playerX = std::min(playerX,  1.0f - playerHalfWidth);

            // Dash (UP) — only when charge full
            bool upPressed = (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS);
            if (dashState == DashState::IDLE)
            {
                if (upPressed && !dashKeyHeld && dashReady) {
                    dashCharge  = 0;
                    dashReady   = false;
                    dashState   = DashState::LUNGING;
                    dashTargetY = PLAYER_Y_HOME + DASH_DIST;
                }
                dashKeyHeld = upPressed;
            }
            else if (dashState == DashState::LUNGING)
            {
                playerY += DASH_SPEED * dt;
                if (playerY >= dashTargetY) { playerY = dashTargetY; dashState = DashState::RETURNING; }
            }
            else if (dashState == DashState::RETURNING)
            {
                playerY -= RETURN_SPEED * dt;
                if (playerY <= PLAYER_Y_HOME) {
                    playerY   = PLAYER_Y_HOME;
                    dashState = DashState::IDLE;
                    dashKeyHeld = upPressed;
                }
            }

            // Speed ramp
            if (elapsed >= nextSpeedIncrease) {
                nextSpeedIncrease += 20.0f;
                speedMultiplier   += 0.25f;
            }

            // New obstacle every 20 s
            if (elapsed >= nextObstacleSpawn && (int)obstacles.size() < MAX_OBSTACLES) {
                nextObstacleSpawn += obstacleSpawnInterval;
                obstacles.push_back(createObstacle(0.0f));
            }

            // ── #3 & #4  Live record tracking ────────────────────────────────
            // Once the player has survived longer than the old top score,
            // flip recordBeatenMid. This does NOT end the game.
            if (!recordBeatenMid && prevTopScore > 0 && (int)elapsed > prevTopScore)
                recordBeatenMid = true;

            // Move obstacles & collision
            for (auto& ob : obstacles) {
                if (!ob.active) { ob.spawnDelay -= dt; if (ob.spawnDelay<=0) ob.active=true; continue; }
                float prevY = ob.y;
                ob.y -= ob.speed * speedMultiplier * dt;

                // Charge dash
                if (!dashReady && prevY >= playerY && ob.y < playerY)
                    if (fabs(ob.x - playerX) < 0.55f) {
                        dashCharge = std::min(dashCharge + 1, DASH_CHARGE_MAX);
                        if (dashCharge >= DASH_CHARGE_MAX) dashReady = true;
                    }

                if (ob.y < -1.1f) resetObstacle(ob);

                if (checkCollision(playerX, playerY, ob.x, ob.y)) {
                    gameOver      = true;
                    finalTime     = (int)elapsed;
                    // ── #4: YOU WIN if player had already beaten the record
                    //        YOU LOSE otherwise
                    beatHighScore = recordBeatenMid;
                    submitScore(finalTime);
                    currentScreen = Screen::GAME_OVER;
                    std::cout << (beatHighScore ? "YOU WIN! " : "YOU LOSE! ")
                              << finalTime << " s\n";
                }
            }
        }

        // ── GAME_OVER screen input ────────────────────────────────────────────
        else if (currentScreen == Screen::GAME_OVER)
        {
            // ── #1 Play Again — R key ─────────────────────────────────────────
            bool rDown = (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS);
            if (rDown && rKeyWasUp)
                resetGame(startTime, lastTime);
            rKeyWasUp = !rDown;
        }

        // ── Draw ──────────────────────────────────────────────────────────────
        glClearColor(0.05f,0.05f,0.08f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glUseProgram(prog);

        // ── TITLE screen render ───────────────────────────────────────────────
        if (currentScreen == Screen::TITLE)
        {
            glBindVertexArray(textVAO);

            // ── #6 "DODGE ME IF YOU CAN" centred on screen ───────────────────
            // Row 1: "DODGE ME"  (8 chars)
            float t1W = 8 * 6.0f * PIX;
            drawTextDirect(textVBO, offsetLoc, colorLoc,
                           FONT_TITLE_ROW1, 8,
                           -t1W / 2.0f, 0.25f, PIX,
                           1.0f, 0.85f, 0.1f);   // gold

            // Row 2: "IF YOU CAN"  (10 chars)
            float t2W = 10 * 6.0f * PIX;
            drawTextDirect(textVBO, offsetLoc, colorLoc,
                           FONT_TITLE_ROW2, 10,
                           -t2W / 2.0f, 0.25f - 10.0f * PIX, PIX,
                           1.0f, 0.85f, 0.1f);   // gold

            // "PRESS SPACE TO PLAY" hint
            float hintW = 19 * 6.0f * PIX;
            drawTextDirect(textVBO, offsetLoc, colorLoc,
                           FONT_HINT, 19,
                           -hintW / 2.0f, -0.15f, PIX * 0.75f,
                           0.6f, 0.6f, 0.6f);    // dim grey

            // "E / N : EXIT" hint
            float exitHintW = 12 * 6.0f * PIX;
            drawTextDirect(textVBO, offsetLoc, colorLoc,
                           FONT_EXIT_HINT, 12,
                           -exitHintW / 2.0f, -0.28f, PIX * 0.75f,
                           0.5f, 0.5f, 0.5f);
        }

        // ── PLAYING screen render ─────────────────────────────────────────────
        if (currentScreen == Screen::PLAYING || currentScreen == Screen::GAME_OVER)
        {
            // Player triangle
            float pR = std::min(elapsed/10.0f,1.0f), pG = 1.0f-pR;
            glUniform2f(offsetLoc, playerX, playerY);
            glUniform4f(colorLoc, pR, pG, 1.0f, 1.0f);
            glBindVertexArray(triVAO);
            glDrawArrays(GL_TRIANGLES,0,3);

            // Obstacles
            glBindVertexArray(sqVAO);
            for (auto& ob : obstacles) {
                if (!ob.active) continue;
                glUniform2f(offsetLoc, ob.x, ob.y);
                glUniform4f(colorLoc, 1.0f, 0.2f, 0.0f, 1.0f);
                glDrawArrays(GL_TRIANGLES,0,6);
            }

            // ── Dash charge bar (bottom-centre) ──────────────────────────────
            glBindVertexArray(textVAO);
            {
                float segW=0.06f, segH=0.025f, gap2=0.012f;
                float totalW = DASH_CHARGE_MAX*segW + (DASH_CHARGE_MAX-1)*gap2;
                float sx0 = -totalW/2.0f, barY = -0.88f;
                for (int i = 0; i < DASH_CHARGE_MAX; ++i) {
                    float sx = sx0 + i*(segW+gap2);
                    float cr,cg,cb;
                    if (dashReady) {
                        float p = 0.6f + 0.4f*sinf((float)now*6.0f);
                        cr=p; cg=p*0.85f; cb=0.0f;
                    } else {
                        bool filled = (i < dashCharge);
                        cr = filled?0.2f:0.08f;
                        cg = filled?0.6f:0.12f;
                        cb = filled?1.0f:0.25f;
                    }
                    float sv[]={sx,barY,sx+segW,barY,sx+segW,barY+segH,
                                sx+segW,barY+segH,sx,barY+segH,sx,barY};
                    glBindBuffer(GL_ARRAY_BUFFER, textVBO);
                    glBufferSubData(GL_ARRAY_BUFFER,0,sizeof(sv),sv);
                    glUniform2f(offsetLoc,0,0);
                    glUniform4f(colorLoc,cr,cg,cb,1.0f);
                    glDrawArrays(GL_TRIANGLES,0,6);
                }
            }

            // Leaderboard bars (top-right)
            glBindVertexArray(textVAO);
            {
                float baseY=0.92f, rowH=0.07f;
                for (int i=0;i<(int)highScores.size();++i) {
                    float barW=std::min((highScores[i]/180.0f)*0.32f,0.32f);
                    float barX=0.62f, barY=baseY-i*rowH;
                    float r=0.5f,g=0.5f,b=0.5f;
                    if(i==0){r=1.0f;g=0.85f;b=0.1f;}
                    else if(i==1){r=0.75f;g=0.75f;b=0.80f;}
                    else if(i==2){r=0.80f;g=0.50f;b=0.20f;}
                    float bv[]={barX,barY-.018f,barX+barW,barY-.018f,barX+barW,barY+.018f,
                                 barX+barW,barY+.018f,barX,barY+.018f,barX,barY-.018f};
                    glBindBuffer(GL_ARRAY_BUFFER,textVBO);
                    glBufferSubData(GL_ARRAY_BUFFER,0,sizeof(bv),bv);
                    glUniform2f(offsetLoc,0,0);
                    glUniform4f(colorLoc,r,g,b,0.9f);
                    glDrawArrays(GL_TRIANGLES,0,6);
                }
            }

            // ── #3 Mid-game "YOU BEAT THE RECORD!" banner ────────────────────
            if (recordBeatenMid && !gameOver) {
                glBindVertexArray(textVAO);
                float bannerW = 20 * 6.0f * PIX * 0.7f;
                drawTextDirect(textVBO, offsetLoc, colorLoc,
                               FONT_RECORD_BANNER, 20,
                               -bannerW/2.0f, 0.95f, PIX*0.7f,
                               0.2f, 1.0f, 0.4f);  // green flash
            }
        }

        // ── GAME OVER overlay ─────────────────────────────────────────────────
        if (currentScreen == Screen::GAME_OVER)
        {
            glBindVertexArray(textVAO);

            // "GAME OVER"
            for (auto& q : gameOverQuads)
                drawPixelQuad(textVBO, offsetLoc, colorLoc, q, 1.0f, 0.15f, 0.15f);

            // ── #4 "YOU WIN" (beat record mid-game) or "YOU LOSE" ─────────────
            if (beatHighScore) {
                for (auto& q : youWinQuads)
                    drawPixelQuad(textVBO, offsetLoc, colorLoc, q, 0.2f, 1.0f, 0.4f);
            } else {
                for (auto& q : youLoseQuads)
                    drawPixelQuad(textVBO, offsetLoc, colorLoc, q, 1.0f, 0.4f, 0.2f);
            }

            // ── #1 "R: PLAY AGAIN" prompt ─────────────────────────────────────
            float raW = 13 * 6.0f * PIX;
            drawTextDirect(textVBO, offsetLoc, colorLoc,
                           FONT_PLAY_AGAIN_PROMPT, 13,
                           -raW/2.0f, -0.30f, PIX,
                           0.8f, 0.8f, 0.2f);   // yellow

            // ── #2 "E/N: EXIT" prompt ─────────────────────────────────────────
            float exW = 10 * 6.0f * PIX;
            drawTextDirect(textVBO, offsetLoc, colorLoc,
                           FONT_EXIT_PROMPT, 10,
                           -exW/2.0f, -0.44f, PIX,
                           0.8f, 0.3f, 0.3f);   // red-ish
        }

        glfwSwapBuffers(window);
    }

    glfwTerminate();
    return 0;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}